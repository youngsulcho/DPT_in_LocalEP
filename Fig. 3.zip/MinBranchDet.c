#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

long myrand(long N)
{
	long n;
	n = N*drand48();
	if(n == N)
		n--;
	return n;
}

long power(long m, long n)
{
	long result=1, i;
	for(i=0; i<n; i++)
		result *= m;
	return result;
}

long numoffspring(long numtrial, double p)
{
	long i, result=0;
	for(i=0; i<numtrial; i++)
	{
		if(drand48() < p)
			result ++;
	}

	return result;
}

void swap(long* a, long* b)
{
	long temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

typedef struct Node {
	struct Node* parent;
	long size, ns, nt;
} Node;

void init(Node* x, long nodeindex);
Node* findRoot(Node* x);
void merge(Node* x, Node* y);
void makenetwork();
long MinBranchDet(double prob);

long degree, numgen, **link, N, min_nboundary, *nodelist;
Node *nodes;

int main(int argc, char* argv[])
{
	long i, ensemble, nensemble, inittime;
	double Pinf, prob, minp, maxp, deltap;
	char filename1[100], filename2[100];
	FILE *fp1, *fp2;

	if(argc<7)
	{
		printf("./a.out z [numgen] minp deltap maxp nensemble\n");
		return 1;
	}

	degree = atol(argv[1]);
	numgen = atol(argv[2]);
	minp = atof(argv[3]);
	deltap = atof(argv[4]);
	maxp = atof(argv[5]);
	nensemble = atol(argv[6]);

	srand48(3);

	min_nboundary = (power(degree-1, numgen)-1)/(degree-2);
	N = (power(degree-1, numgen+1)-1)/(degree-2);

	printf("N:%d\n", N);

	link = (long**)malloc(sizeof(long*)*min_nboundary);
	nodelist = (long*)malloc(sizeof(long)*min_nboundary);
	nodes = malloc(sizeof(Node)*N);

	makenetwork();
	
	sprintf(filename1, "MinBranchDet_z%d_n%d_Pinf", degree, numgen);
	sprintf(filename2, "MinBranchDet_z%d_n%d_currentstage", degree, numgen);

	for(prob=minp; prob<maxp; prob += deltap)
	{
		inittime = time(NULL);

		Pinf = 0;
		for(ensemble=0; ensemble<nensemble; ensemble ++)
		{			
			for(i=0; i<N; i++)
                 		init(nodes+i, i);

			if(MinBranchDet(prob) > 0)
				Pinf += 1.0/nensemble;	
		}
		
		fp1 = fopen(filename1, "a");
		fprintf(fp1, "%f %g %d\n", prob, Pinf, nensemble);
		fclose(fp1);

		fp2 = fopen(filename2, "a");
		fprintf(fp2, "prob:%f nens:%d time:%f\n", prob, nensemble, ((double)time(NULL)-inittime)/60.0);
		fclose(fp2);
	}

	for(i=0; i<min_nboundary; i++)
		free(link[i]);
	free(link);
	free(nodelist), free(nodes);

	return 0;
}

long MinBranchDet(double prob)
{
	long n, n1, n2, _node, i, j;
	long neighbor[degree-1], neighborcsize[degree-1];

	for(_node = min_nboundary-1; _node >= 0; _node--)
	{
		n1 = nodelist[_node];

		for(i=0; i<degree-1; i++)
		{
			neighbor[i] = link[n1][i];
			neighborcsize[i] = findRoot(nodes+neighbor[i])->size;
		}

		for(i=degree-3; i>=0; i--)
		{
			for(j=0; j<=i; j++)
			{
				if(neighborcsize[j] > neighborcsize[j+1])
				{
					swap(&neighborcsize[j], &neighborcsize[j+1]);
					swap(&neighbor[j], &neighbor[j+1]);
				}
			}
		}

		n = numoffspring(degree-1, prob);

		for(i=0; i<n; i++)
		{
			n2 = neighbor[i];
			merge(nodes+n1, nodes+n2);
		}
	}

	return findRoot(nodes)->nt;	
}

void makenetwork()
{
	long i, j, node, gen, nextgennode, evennode;
	long shellnode, nextshellnode, shellinit, nextshellinit;

	for(gen=0; gen<numgen; gen++)
	{
		if(gen == 0)
			shellinit = 0, nextshellinit = 1;
		else
		{
			shellinit = (power(degree-1, gen)-1)/(degree-2);
			nextshellinit = (power(degree-1, gen+1)-1)/(degree-2);
		}

		nextshellnode = nextshellinit;
		for(node=shellinit; node < nextshellinit; node++)
		{
			link[node] = (long*)malloc(sizeof(long)*(degree-1));
			for(i=0; i<degree-1; i++)
			{
				link[node][i] = nextshellnode;
				nextshellnode ++;
			}

			nodelist[node] = node;
		}
	}
}

void init(Node* x, long nodeindex){
	x->parent = x;
	x->size = 1;
	if(nodeindex < min_nboundary)
		x->ns = 1, x->nt = 0;
	else
		x->ns = 0, x->nt = 1;
}

Node* findRoot(Node* x){
	if(x->parent == x)
		return x;

	else
	{
		x -> parent = findRoot(x->parent);
		return x->parent;
	}
}

void merge(Node* x, Node* y){
	Node* xRoot = findRoot(x);
	Node* yRoot = findRoot(y);
	if(xRoot != yRoot)
	{
		if(xRoot->size < yRoot->size) {
			xRoot->parent = yRoot;
			yRoot->size += xRoot->size;
			yRoot->ns += xRoot->ns, yRoot->nt += xRoot->nt;
		}
		else{
			yRoot->parent = xRoot;
			xRoot->size += yRoot->size;
			xRoot->ns += yRoot->ns, xRoot->nt += yRoot->nt;
		}
	}
}
