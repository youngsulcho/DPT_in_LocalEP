#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

long myrand(long N)
{
	long n;
	n = N*drand48();
	if(n == N)
		n--;
	return n;
}

long power(long m, long n)
{
	long result=1, i;
	for(i=0; i<n; i++)
		result *= m;
	return result;
}

void swap(long* a, long* b)
{
	long temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

typedef struct Node {
	struct Node* parent;
	long size, nt, index;
} Node;

void init(Node* x, long nodeindex);
void merge(Node* x, Node* y);
void makenetwork();
void Bubble(long* neighbor, long* neighborcsize);
void Rewire(long Rewirenodeindex);
void parentupdate(Node* x);

long degree, numgen, **link, N, min_nboundary, *nodelist, *excessdeg, Oldnt, Oldsize, Newnt, Newsize;
Node *nodes;

int main(int argc, char* argv[])
{
	long numlink, i, j, ensemble, nensemble, gen, node, _n1index, n1index, shellinit, nextshellinit, Rewirenodeindex, nRewirenode, *Rewirenodeset;
	Node* Rewirenode;
	long mincsize, nnodelist, inittime;
	double *Pinf, prob, *fracRewire;
	FILE *fp2;
	char filename2[100];

	if(argc<4)
	{
		printf("./a.out [degree] numgen nensemble\n");
		return 1;

	}

	degree = atol(argv[1]);
	numgen = atol(argv[2]);
	nensemble = atol(argv[3]);

	srand48(3);

	min_nboundary = (power(degree-1, numgen)-1)/(degree-2);
	N = (power(degree-1, numgen+1)-1)/(degree-2);

	link = (long**)malloc(sizeof(long*)*min_nboundary);
	excessdeg = (long*)calloc(sizeof(long), min_nboundary);

	for(i=0; i<min_nboundary; i++)
		link[i] = (long*)malloc(sizeof(long)*(degree-1));

	Pinf = (double*)calloc(sizeof(double), N);	
	fracRewire = (double*)calloc(sizeof(double), N);	

	nodelist = (long*)malloc(sizeof(long)*min_nboundary);
	Rewirenodeset = (long*)malloc(sizeof(long)*min_nboundary);
	nodes = malloc(sizeof(Node)*N);

	makenetwork();

	inittime = time(NULL);
	for(ensemble=0; ensemble<nensemble; ensemble++)
	{		 
		for(i=0; i<N; i++)
			init(nodes+i, i);
	
		nnodelist = min_nboundary;
		for(i=0; i<min_nboundary; i++)
			nodelist[i] = i, excessdeg[i] = degree-1;

		for(numlink=0; numlink<N-1; numlink++)
		{
			_n1index = myrand(nnodelist);
			n1index = nodelist[_n1index];

			if(drand48() > (double)excessdeg[n1index]/(degree-1))
			{
				numlink--;
				continue;
			}

			excessdeg[n1index]--;

			if(excessdeg[n1index]==0)
			{
				nodelist[_n1index] = nodelist[nnodelist-1];
				nnodelist--;
			}

			Rewire(n1index);

			nRewirenode = 0;
			Rewirenode = nodes + n1index;
			while((Rewirenode -> parent) != Rewirenode)
			{
				Rewirenodeset[nRewirenode++] = (Rewirenode -> parent)->index;
				Rewirenode = Rewirenode -> parent;
			}

			fracRewire[numlink+1] += (nRewirenode+1.0)/min_nboundary;

			for(i=0; i<nRewirenode; i++)
			{
				Rewirenodeindex = i;
				Rewirenode = nodes + Rewirenodeset[Rewirenodeindex];
				Rewire(Rewirenode->index);
			}	

			if(nodes->nt > 0)
				Pinf[numlink+1] += 1.0/nensemble;
		}
	}

	char filename1[100];
	FILE *fp1;
	sprintf(filename1, "SuccessiveRewire_z%d_n%d_Pinf", degree, numgen);
	fp1 = fopen(filename1, "w");
	for(i=0; i<=N-1; i++)
		fprintf(fp1, "%.10f %g\n", (double)i/(N-1), Pinf[i]);
	fclose(fp1);

	sprintf(filename1, "SuccessiveRewire_z%d_n%d_fracRewire", degree, numgen);
	fp1 = fopen(filename1, "w");
	for(i=0; i<=N-1; i++)
		fprintf(fp1, "%.10f %g\n", (double)i/(N-1), fracRewire[i]/nensemble);
	fclose(fp1);	

	fp2 = fopen("SuccessiveRewire_time", "a");
	fprintf(fp2, "z:%d n:%d nens:%d time:%g\n", degree, numgen, nensemble, ((double)time(NULL)-inittime)/60);
	fclose(fp2);

	for(i=0; i<min_nboundary; i++)
		free(link[i]);
	free(link);
	free(Rewirenodeset), free(nodelist), free(nodes), free(excessdeg), free(Pinf), free(fracRewire);

	return 0;
}

void Rewire(long Rewirenodeindex)
{
	long RewirenodeNumlink, i, neighbor[degree-1], neighborcsize[degree-1];
	Node *n1, *n2;

	n1 = nodes + Rewirenodeindex;
	Oldnt = n1 -> nt;
	Oldsize = n1 -> size;
	n1 -> nt = 0;
	n1 -> size = 1;

	for(i=0; i<degree-1; i++)
	{
		neighbor[i] = link[Rewirenodeindex][i];
		neighborcsize[i] = (nodes+neighbor[i])->size;
	}

	Bubble(neighbor, neighborcsize);

	for(i=0; i<degree-1; i++)
		(nodes + neighbor[i]) -> parent = (nodes + neighbor[i]);
	
	RewirenodeNumlink = degree-1-excessdeg[Rewirenodeindex];

	for(i=0; i<RewirenodeNumlink; i++)
	{
		n2 = nodes + neighbor[i];
		merge(n1, n2);
	}

	Newnt = n1 -> nt;
	Newsize = n1 -> size;
	parentupdate(n1);
}

void makenetwork()
{
	long i, j, node, gen, nextgennode, evennode;
	long shellnode, nextshellnode, shellinit, nextshellinit;

	for(gen=0; gen<numgen; gen++)
	{
		if(gen == 0)
			shellinit = 0, nextshellinit = 1;
		else
		{
			shellinit = (power(degree-1, gen)-1)/(degree-2);
			nextshellinit = (power(degree-1, gen+1)-1)/(degree-2);
		}

		nextshellnode = nextshellinit;
		for(node=shellinit; node < nextshellinit; node++)
		{
			for(i=0; i<degree-1; i++)
			{
				link[node][i] = nextshellnode;
				nextshellnode ++;
			}

			excessdeg[node] = degree-1;
			nodelist[node] = node;
		}
	}
}

void Bubble(long* neighbor, long* neighborcsize)
{
	long i, j;

	for(i=degree-3; i>=0; i--)
	{
		for(j=0; j<=i; j++)
		{
			if(neighborcsize[j] > neighborcsize[j+1])
			{
				swap(&neighborcsize[j], &neighborcsize[j+1]);
				swap(&neighbor[j], &neighbor[j+1]);
			}
		}
	}
}

void init(Node* x, long nodeindex){
	x->parent = x;
	x->size = 1;
	x->index = nodeindex;
	if(nodeindex < min_nboundary)
		x->nt = 0;
	else
		x->nt = 1;
}

void merge(Node* x, Node* y){
	y->parent = x;
	x->size += y->size;
	x->nt += y->nt; 
}

void parentupdate(Node* x)
{	
	if(x->parent != x)
	{
		(x -> parent) -> nt += Newnt - Oldnt;
		(x -> parent) -> size += Newsize - Oldsize;
		parentupdate(x->parent);
	}
}
