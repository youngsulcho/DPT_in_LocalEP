#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

long myrand(long N)
{
	long n;
	n = N*drand48();
	if(n == N)
		n--;
	return n;
}

long power(long m, long n)
{
	long result=1, i;
	for(i=0; i<n; i++)
		result *= m;
	return result;
}

void swap(long* a, long* b)
{
	long temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void makenetwork(long **link);
long BFS(long seed, long** A, long* deg);
long dirBFS(long node, long neighbor, long** A, long* deg);
void Bubble(long* neighbor, long* neighborcsize, long length);
void Rewire(long n1);
long getnNotordered(long** A, long* deg);

long ensemble, nensemble, degree, **link, *linkdeg, **A, *deg, N;
long *Queue, *Visited;
double p;

int main(int argc, char* argv[])
{
	long seed, nRewire, maxcluster, i, j, numlink, n1, _n1, *nodelist, nnodelist, L;
	long *Occupylist, intp, maxintp, nNotordered, meannRewire, inittime;
	double minp, maxp, deltap, **Pinf, **fracNotordered;
	char filename1[100], filename2[100], filename3[100];
	FILE *fp1, *fp2, *fp3;

	if(argc<9)
	{
		printf("./a.out N z minp maxp deltap meannrewire nensemble seed\n");
		return 1;
	}

	N = atol(argv[1]);
	degree = atol(argv[2]);
	minp = atof(argv[3]);
	maxp = atof(argv[4]);
	deltap = atof(argv[5]);
	meannRewire = atol(argv[6]);
	nensemble = atol(argv[7]);
	seed = atol(argv[8]);

	if(N%2 == 1)
	{
		printf("N should be even\n");
		return 1;
	}

	L = (N*degree)/2;

	srand48(seed);

	link = (long**)malloc(sizeof(long*)*N);
	linkdeg = (long*)malloc(sizeof(long)*N);
	nodelist = (long*)malloc(sizeof(long)*N/2);
	A = (long**)malloc(sizeof(long*)*N);
	deg = (long*)malloc(sizeof(long)*N);
	Queue = (long*)malloc(sizeof(long)*N);
	Visited = (long*)malloc(sizeof(long)*N);
	Occupylist = (long*)malloc(sizeof(long)*L);

	for(i=0; i<N; i++)
		link[i] = (long*)malloc(sizeof(long)*degree);
	for(i=0; i<N; i++)
		A[i] = (long*)malloc(sizeof(long)*degree);

	maxintp = 0;
	for(p=minp; p<maxp; p+=deltap)
		maxintp ++;

	Pinf = (double**)malloc(sizeof(double*)*maxintp);
	fracNotordered = (double**)malloc(sizeof(double*)*maxintp);	
	for(i=0; i<maxintp; i++)
	{
		Pinf[i] = (double*)calloc(sizeof(double), meannRewire+1);
		fracNotordered[i] = (double*)calloc(sizeof(double), meannRewire+1);
	}

	makenetwork(link);

	inittime = time(NULL);
	for(ensemble=0; ensemble<nensemble; ensemble ++)
	{
		fp2 = fopen("GlobalRewire_SuccessiveBipartite_nNotordered_time", "a");
		fprintf(fp2, "seed:%d N:%d ens:%d minp:%g maxp:%g deltap:%g time(min):%g\n", seed, N, ensemble, minp, maxp, deltap, ((double)time(NULL)-inittime)/60);
		inittime = time(NULL);
		fclose(fp2);

		for(i=0; i<N; i++)
			deg[i] = 0;	

		for(i=0; i<N/2; i++)
			nodelist[i] = i;
		nnodelist = N/2;

		for(numlink=0; numlink<L; numlink++)
		{
			_n1 = myrand(nnodelist);
			n1 = nodelist[_n1];
	
			if(drand48() > (linkdeg[n1]-deg[n1])/((double)linkdeg[n1]))
			{
				numlink --;
				continue;
			}

			Occupylist[numlink] = n1;
			deg[n1]++;

			if(deg[n1]==linkdeg[n1])
			{
				nodelist[_n1] = nodelist[nnodelist-1];
				nnodelist--;
			}
		}

		intp = 0;
		for(p=minp; p<maxp; p+=deltap)
		{
			for(i=0; i<N; i++)
				deg[i] = 0;

			for(numlink=0; numlink<p*N*degree/2; numlink++)
			{
				n1 = Occupylist[numlink];
				deg[n1]++;
				Rewire(n1);	
			}	
		
			nRewire = 0;

			while(nRewire < meannRewire*N)
			{
				if(nRewire%N == 0)
				{
					nNotordered = getnNotordered(A, deg);
				
					maxcluster = 0;
					for(i=0; i<N; i++)
					{       
						if(BFS(i, A, deg)>maxcluster)
							maxcluster = BFS(i, A, deg);
					}
				
					Pinf[intp][nRewire/N] += (double)maxcluster/N;
					fracNotordered[intp][nRewire/N] += (double)nNotordered/N;
				}
	
				n1 = myrand(N/2);
				Rewire(n1); 
				nRewire ++;
			}

			intp++;
		}
	}

//	sprintf(filename1, "GlobalRewire_SuccessiveBipartite_N%d_z%d_G", N, degree);
//	fp1 = fopen(filename1, "w");
//	for(i=0; i<maxintp; i++)
//	{
//		for(j=0; j<meannRewire; j++)
//			fprintf(fp1, "%.10f %d %g\n", minp + deltap*i, j, Pinf[i][j]/nensemble);
//	}
//	fclose(fp1);

	sprintf(filename1, "GlobalRewire_SuccessiveBipartite_N%d_z%d_nNotordered_seed%d", N, degree, seed);
	fp1 = fopen(filename1, "a");
	for(i=0; i<maxintp; i++)
	{
		for(j=0; j<meannRewire; j++)
			fprintf(fp1, "%.10f %d %g\n", minp + deltap*i, j, fracNotordered[i][j]/nensemble);	
	}               
	fclose(fp1);  

	for(i=0; i<maxintp; i++)
		free(Pinf[i]), free(fracNotordered[i]);	
	for(i=0; i<N; i++)
		free(link[i]);
	for(i=0; i<N; i++)
		free(A[i]);
	free(link), free(linkdeg), free(A), free(deg), free(nodelist);
	free(Occupylist), free(Queue), free(Visited);
	free(Pinf), free(fracNotordered);
		
	return 0;
}

long getnNotordered(long** A, long* deg)
{
	long i, j, k, n2, nNotordered, Notorderedcheck;
	long Notneighborcheck, Notneighbor[degree], nNotneighbor;
	long neighborcsize[degree], Notneighborcsize[degree];

	nNotordered = 0;
	for(i=0; i<N/2; i++)
	{
		nNotneighbor=0;
		for(j=0; j<linkdeg[i]; j++)
		{
			n2 = link[i][j];
			Notneighborcheck=0;
			for(k=0; k<deg[i]; k++)
			{
				if(A[i][k] == n2)
				{
					Notneighborcheck = 1;
					break;
				}
			}

			if(Notneighborcheck == 0)
				Notneighbor[nNotneighbor++] = n2;
		}

		for(j=0; j<deg[i]; j++)
			neighborcsize[j] = dirBFS(i, A[i][j], A, deg);
		for(j=0; j<nNotneighbor; j++)
			Notneighborcsize[j] = dirBFS(i, Notneighbor[j], A, deg);

		Notorderedcheck = 0;
		for(j=0; j<deg[i]; j++)
		{
			for(k=0; k<nNotneighbor; k++)
			{
				if(Notneighborcsize[k] < neighborcsize[j])
					Notorderedcheck = 1;
			}
		}

		if(Notorderedcheck == 1)
		{
			if(ensemble == 4546 && fabs(p-0.7)<1e-5)
				printf("node:%d\n",i); 
			nNotordered ++;
		}
	}

	return nNotordered;
}

void Rewire(long n1)
{
	long n2, i, j, neighbor[degree], neighborcsize[degree];
	long degn1;	

	for(i=0; i<linkdeg[n1]; i++)
	{
		n2 = link[n1][i];
		for(j=0; j<deg[n2]; j++)
		{
			if(A[n2][j] == n1)
			{
				A[n2][j] = A[n2][deg[n2]-1];
				deg[n2]--;
				break;
			}
		}
	}

	degn1 = deg[n1];
	deg[n1] = 0;
	
	for(i=0; i<linkdeg[n1]; i++)
	{
		neighbor[i] = link[n1][i];
		neighborcsize[i] = BFS(neighbor[i], A, deg);
	}

	Bubble(neighbor, neighborcsize, linkdeg[n1]);

	deg[n1] = degn1;

	for(i=0; i<deg[n1]; i++)
	{
		n2 = neighbor[i];
		A[n1][i] = n2;
		A[n2][deg[n2]++] = n1;
	}
}

long dirBFS(long node, long neighbor, long** A, long* deg)
{
	long i, j, k, n2, checkNode, nNextQueue=0, nCurrentQueue=0, InitCurrentQueue, InitNextQueue, csize;
	
	for(i=0; i<N; i++)
		Visited[i] = 0;
	Queue[0] = node, Queue[1] = neighbor;
	Visited[node] = 1, Visited[neighbor] = 1;
	nCurrentQueue = 1, InitCurrentQueue = 1, InitNextQueue = 2;

	csize = 1, nNextQueue = 0;
	for(i=0; i<deg[neighbor]; i++)
	{
		n2 = A[neighbor][i];
		if(Visited[n2] == 0)
		{
			Queue[InitNextQueue + nNextQueue] = n2;
			Visited[n2] = 1; 
			nNextQueue++;
		}
	}

	csize += nNextQueue;

	while(nNextQueue > 0)
	{
		InitCurrentQueue = InitNextQueue;
		InitNextQueue = InitCurrentQueue + nNextQueue;
		nCurrentQueue = nNextQueue;		

		nNextQueue = 0;
		for(i=0; i<nCurrentQueue; i++)
		{
			checkNode = Queue[InitCurrentQueue+i];	
			for(j=0; j<deg[checkNode]; j++)
			{
				n2 = A[checkNode][j];
				if(Visited[n2] == 0)
				{
					Queue[InitNextQueue + nNextQueue] = n2;
					Visited[n2] = 1;
					nNextQueue ++;
				}
			}
		}

		csize += nNextQueue;
	}

	return csize;
}


long BFS(long seed, long** A, long* deg)
{
	long i, j, k, n2, checkNode, nNextQueue=0, nCurrentQueue=0, InitCurrentQueue, InitNextQueue, csize;

	for(i=0; i<N; i++)
		Visited[i] = 0;
	Queue[0] = seed, Visited[seed] = 1;
	nCurrentQueue = 1, InitCurrentQueue = 0, InitNextQueue = 1;

	csize = 1, nNextQueue = 0;
	for(i=0; i<deg[seed]; i++)
	{
		n2 = A[seed][i];
		if(Visited[n2] == 0)
		{
			Queue[InitNextQueue + nNextQueue] = n2;
			Visited[n2] = 1; 
			nNextQueue++;
		}
	}

	csize += nNextQueue;

	while(nNextQueue > 0)
	{
		InitCurrentQueue = InitNextQueue;
		InitNextQueue = InitCurrentQueue + nNextQueue;
		nCurrentQueue = nNextQueue;		

		nNextQueue = 0;
		for(i=0; i<nCurrentQueue; i++)
		{
			checkNode = Queue[InitCurrentQueue+i];	
			for(j=0; j<deg[checkNode]; j++)
			{
				n2 = A[checkNode][j];
				if(Visited[n2] == 0)
				{
					Queue[InitNextQueue + nNextQueue] = n2;
					Visited[n2] = 1;
					nNextQueue ++;
				}
			}
		}

		csize += nNextQueue;
	}

	return csize;
}


void Bubble(long* neighbor, long* neighborcsize, long length)
{
	long i, j;

	for(i=length-2; i>=0; i--)
	{
		for(j=0; j<=i; j++)
		{
			if(neighborcsize[j] > neighborcsize[j+1])
			{
				swap(&neighborcsize[j], &neighborcsize[j+1]);
				swap(&neighbor[j], &neighbor[j+1]);
			}
		}
	}
}

void makenetwork(long **link)
{
	long *largestubs, *smallstubs, Nlargestubs, Nsmallstubs;
	long L, i, j, k, t, n1index, n2index, n1stub, n2stub, check, ntrial, noexcesscheck;

	Nlargestubs = N*degree/2;
	Nsmallstubs = N*degree/2;
	L = N*degree/2;

	largestubs = (long*)malloc(sizeof(long)*Nlargestubs);
	smallstubs = (long*)malloc(sizeof(long)*Nsmallstubs);

	for(i=0; i<N; i++)
		linkdeg[i] = 0;

	for(i=0; i<N/2; i++)
	{
		for(j=0; j<degree; j++)
		{
			smallstubs[i*degree+j] = i;
			largestubs[i*degree+j] = i+N/2;
		}
	}

	for(t = 1; t <= L; ++t)
	{
		ntrial = 0, noexcesscheck = 0;
		while(1)
		{
			if(ntrial > (Nsmallstubs+Nlargestubs)*N)
			{
				noexcesscheck = 1;
				break;
			}

			ntrial ++;

			n1stub = drand48()*Nsmallstubs;
			n2stub = drand48()*Nlargestubs;
			n1index = smallstubs[n1stub];
			n2index = largestubs[n2stub];

			if(n1index == n2index)
				continue;

			check = 0;
			for(i=0; i<linkdeg[n1index]; i++)
			{
				if(link[n1index][i] == n2index)
				{
					check = 1;
					break;
				}
			}

			if(check == 0)
				break;
		}

		if(noexcesscheck == 1)
			break;

		smallstubs[n1stub] = smallstubs[Nsmallstubs-1], largestubs[n2stub] = largestubs[Nlargestubs-1];

		Nsmallstubs --, Nlargestubs --;

		link[n1index][linkdeg[n1index]] = n2index, link[n2index][linkdeg[n2index]] = n1index;
		linkdeg[n1index]++, linkdeg[n2index]++;
	}

	free(largestubs), free(smallstubs);
}
