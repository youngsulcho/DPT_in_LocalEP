#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

long myrand(long N)
{
	long n;
	n = N*drand48();
	if(n == N)
		n--;
	return n;
}

long power(long m, long n)
{
	long result=1, i;
	for(i=0; i<n; i++)
		result *= m;
	return result;
}

void swap(long* a, long* b)
{
	long temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void makenetwork(long **link);
long BFS(long seed, long** A, long* deg);
long dirBFS(long node, long neighbor, long** A, long* deg);
void Bubble(long* neighbor, long* neighborcsize, long length);
void Rewire(long n1);
long getNewRewirelist(long* NewRewiringlist, long nNewRewiringlist);
long checkNotordered(long n1);
long checkNotorderedInf(long n1);

long nensemble, degree, **link, *linkdeg, **A, *deg, N;
long *Queue, *Visited, *Rewiringcheck, nNotorderedInf, mcluster, *cluster, clusterindex, mcluster;

int main(int argc, char* argv[])
{
	long nRewiringcheck, maxcluster, i, j, k, ensemble, numlink, n1, _n1, *nodelist, nnodelist, L;
	long *Occupylist, inittime, csize;
	long *NewRewiringlist, nNewRewiringlist, *BFScheck;
	double T, *Pinf, meanclustersize, *susceptibility, *fracNotorderedInf;
	char filename1[100], filename2[100], filename3[100];
	FILE *fp1, *fp2, *fp3;

	if(argc<5)
	{
		printf("./a.out N z T nensemble\n");
		return 1;
	}

	N = atol(argv[1]);
	degree = atol(argv[2]);
	T = atof(argv[3]);
	nensemble = atol(argv[4]);

	if(N%2 == 1)
	{
		printf("N should be even\n");
		return 1;
	}

	L = (N*degree)/2;

	srand48(3);

	link = (long**)malloc(sizeof(long*)*N);
	linkdeg = (long*)malloc(sizeof(long)*N);
	nodelist = (long*)malloc(sizeof(long)*N/2);
	A = (long**)malloc(sizeof(long*)*N);
	deg = (long*)malloc(sizeof(long)*N);
	Queue = (long*)malloc(sizeof(long)*N);
	Visited = (long*)malloc(sizeof(long)*N);
	Occupylist = (long*)malloc(sizeof(long)*L);
	susceptibility = (double*)calloc(sizeof(double), L);
	Rewiringcheck = (long*)malloc(sizeof(long)*N/2);
	NewRewiringlist = (long*)malloc(sizeof(long)*N/2);
	cluster = (long*)malloc(sizeof(long)*N);
	fracNotorderedInf = (double*)calloc(sizeof(double), L);

	for(i=0; i<N; i++)
		link[i] = (long*)malloc(sizeof(long)*degree);
	for(i=0; i<N; i++)
		A[i] = (long*)malloc(sizeof(long)*degree);

	Pinf = (double*)calloc(sizeof(double), L);

	BFScheck = (long*)malloc(sizeof(long)*N);

	makenetwork(link);
	
	inittime = time(NULL);
	for(ensemble=0; ensemble<nensemble; ensemble ++)
	{
		fp2 = fopen("LocalRewire_SuccessiveBipartite_nNotorderedInf_time", "a");
		fprintf(fp2, "N:%d ens:%d T:%g time(min):%g\n", N, ensemble, T, ((double)time(NULL)-inittime)/60);
		inittime = time(NULL);
		fclose(fp2);

		for(i=0; i<N; i++)
			deg[i] = 0;	

		for(i=0; i<N/2; i++)
			nodelist[i] = i;
		nnodelist = N/2;

		for(numlink=0; numlink<T*L; numlink++)
		{
			_n1 = myrand(nnodelist);
			n1 = nodelist[_n1];

			if(drand48() > (linkdeg[n1]-deg[n1])/((double)linkdeg[n1]))
			{
				numlink --;
				continue;
			}

			Occupylist[numlink] = n1;
			deg[n1]++;

			if(deg[n1]==linkdeg[n1])
			{
				nodelist[_n1] = nodelist[nnodelist-1];
				nnodelist--;
			}
		}

		for(i=0; i<N; i++)
			deg[i] = 0;

		for(numlink=0; numlink<T*L; numlink++)
		{
			for(i=0; i<N; i++)
				BFScheck[i] = 0;

			maxcluster = 0, meanclustersize = 0, clusterindex = 0;

//			printf("\nnumlink:%d\n", numlink);
			for(i=0; i<N; i++)
			{
				if(BFScheck[i] == 1)
					continue;

				csize = BFS(i, A, deg);
				if(csize > maxcluster)
				{
					maxcluster = csize;
					mcluster = clusterindex;
				}			

				meanclustersize += (double)csize*csize;

//				printf("clusterindex:%d\n", clusterindex);
				for(j=0; j<N; j++)
				{
					if(Visited[j] == 1)
					{
//						printf("%d ", j);
						cluster[j] = clusterindex;
						BFScheck[j] = 1;
					}
				}

//				printf("\n");
				clusterindex ++;
			}			
			
			Pinf[numlink] += (double)maxcluster/N;
			susceptibility[numlink] += meanclustersize/N;

			n1 = Occupylist[numlink];
			deg[n1]++;
		
			for(i=0; i<N/2; i++)
				Rewiringcheck[i] = 0;
			nNewRewiringlist = 1;
			NewRewiringlist[0] = n1;
			Rewiringcheck[n1] = 1;	

			while(nNewRewiringlist > 0)
			{
				for(i=0; i<nNewRewiringlist; i++)
					Rewire(NewRewiringlist[i]);
				nNewRewiringlist = getNewRewirelist(NewRewiringlist, nNewRewiringlist);
			}

	//		printf("clusters\n");
	//		for(i=0; i<N; i++)
	//			printf("%d:%d\n", i, cluster[i]);
			
//			printf("mcluster:%d\n", mcluster);
	//		printf("\n");

			nNotorderedInf = 0;
			for(i=0; i<N/2; i++)
			{
				
//				printf("checknode:%d\n", i);
//				for(j=0; j<linkdeg[i]; j++)
//					printf("Allneighbor:%d cluster:%d\n", link[i][j], cluster[link[i][j]]);
//				for(j=0; j<deg[i]; j++)
//					printf("neighbor:%d cluster:%d\n", A[i][j], cluster[A[i][j]]);
//				printf("checknode:%d checkresult:%d\n\n", i, checkNotorderedInf(i));
				nNotorderedInf += checkNotorderedInf(i);
			}

			fracNotorderedInf[numlink] += (double)nNotorderedInf/N;
			
//			printf("nNotorderedInf:%d\n", nNotorderedInf);
		}
	}

	sprintf(filename1, "LocalRewire_SuccessiveBipartite_N%d_z%d_T%.2f_G_meancluster_nNotorderedInf", N, degree, T);
	fp1 = fopen(filename1, "w");
	for(i=0; i<T*L; i++)
		fprintf(fp1, "%.10f %g %g %g\n", (double)i/L, Pinf[i]/nensemble, susceptibility[i]/nensemble, fracNotorderedInf[i]/nensemble);
	fclose(fp1);

	for(i=0; i<N; i++)
		free(link[i]);
	for(i=0; i<N; i++)
		free(A[i]);
	free(link), free(linkdeg), free(A), free(deg), free(nodelist);
	free(Occupylist), free(Queue), free(Visited), free(susceptibility);
	free(Rewiringcheck), free(NewRewiringlist);
	free(Pinf), free(BFScheck), free(cluster), free(fracNotorderedInf);
		
	return 0;
}

void Rewire(long n1)
{
	long n2, i, j, neighbor[degree], neighborcsize[degree];
	long degn1;	

	for(i=0; i<linkdeg[n1]; i++)
	{
		n2 = link[n1][i];
		for(j=0; j<deg[n2]; j++)
		{
			if(A[n2][j] == n1)
			{
				A[n2][j] = A[n2][deg[n2]-1];
				deg[n2]--;
				break;
			}
		}
	}

	degn1 = deg[n1];
	deg[n1] = 0;
	
	for(i=0; i<linkdeg[n1]; i++)
	{
		neighbor[i] = link[n1][i];
		neighborcsize[i] = BFS(neighbor[i], A, deg);
	}

	Bubble(neighbor, neighborcsize, linkdeg[n1]);

	deg[n1] = degn1;

	for(i=0; i<deg[n1]; i++)
	{
		n2 = neighbor[i];
		A[n1][i] = n2;
		A[n2][deg[n2]++] = n1;
	}
}

long dirBFS(long node, long neighbor, long** A, long* deg)
{
	long i, j, k, n2, checkNode, nNextQueue=0, nCurrentQueue=0, InitCurrentQueue, InitNextQueue, csize;

	for(i=0; i<N; i++)
		Visited[i] = 0;
	Queue[0] = node, Queue[1] = neighbor;
	Visited[node] = 1, Visited[neighbor] = 1;
	nCurrentQueue = 1, InitCurrentQueue = 1, InitNextQueue = 2;

	csize = 1, nNextQueue = 0;
	for(i=0; i<deg[neighbor]; i++)
	{
		n2 = A[neighbor][i];
		if(Visited[n2] == 0)
		{
			Queue[InitNextQueue + nNextQueue] = n2;
			Visited[n2] = 1; 
			nNextQueue++;
		}
	}

	csize += nNextQueue;

	while(nNextQueue > 0)
	{
		InitCurrentQueue = InitNextQueue;
		InitNextQueue = InitCurrentQueue + nNextQueue;
		nCurrentQueue = nNextQueue;		

		nNextQueue = 0;
		for(i=0; i<nCurrentQueue; i++)
		{
			checkNode = Queue[InitCurrentQueue+i];	
			for(j=0; j<deg[checkNode]; j++)
			{
				n2 = A[checkNode][j];
				if(Visited[n2] == 0)
				{
					Queue[InitNextQueue + nNextQueue] = n2;
					Visited[n2] = 1;
					nNextQueue ++;
				}
			}
		}

		csize += nNextQueue;
	}

	return csize;
}


long BFS(long seed, long** A, long* deg)
{
	long i, j, k, n2, checkNode, nNextQueue=0, nCurrentQueue=0, InitCurrentQueue, InitNextQueue, csize;

	for(i=0; i<N; i++)
		Visited[i] = 0;
	Queue[0] = seed, Visited[seed] = 1;
	nCurrentQueue = 1, InitCurrentQueue = 0, InitNextQueue = 1;

	csize = 1, nNextQueue = 0;
	for(i=0; i<deg[seed]; i++)
	{
		n2 = A[seed][i];
		if(Visited[n2] == 0)
		{
			Queue[InitNextQueue + nNextQueue] = n2;
			Visited[n2] = 1; 
			nNextQueue++;
		}
	}

	csize += nNextQueue;

	while(nNextQueue > 0)
	{
		InitCurrentQueue = InitNextQueue;
		InitNextQueue = InitCurrentQueue + nNextQueue;
		nCurrentQueue = nNextQueue;		

		nNextQueue = 0;
		for(i=0; i<nCurrentQueue; i++)
		{
			checkNode = Queue[InitCurrentQueue+i];	
			for(j=0; j<deg[checkNode]; j++)
			{
				n2 = A[checkNode][j];
				if(Visited[n2] == 0)
				{
					Queue[InitNextQueue + nNextQueue] = n2;
					Visited[n2] = 1;
					nNextQueue ++;
				}
			}
		}

		csize += nNextQueue;
	}

	return csize;
}


void Bubble(long* neighbor, long* neighborcsize, long length)
{
	long i, j;

	for(i=length-2; i>=0; i--)
	{
		for(j=0; j<=i; j++)
		{
			if(neighborcsize[j] > neighborcsize[j+1])
			{
				swap(&neighborcsize[j], &neighborcsize[j+1]);
				swap(&neighbor[j], &neighbor[j+1]);
			}
		}
	}
}

long checkNotordered(long n1)
{
	long i, j, n2, Notorderedcheck;
	long Notneighborcheck, Notneighbor[degree], nNotneighbor;
	long neighborcsize[degree], Notneighborcsize[degree];

	nNotneighbor = 0;
	for(i=0; i<linkdeg[n1]; i++)
	{
		n2 = link[n1][i];
		Notneighborcheck=0;
		for(j=0; j<deg[n1]; j++)
		{
			if(A[n1][j] == n2)
			{
				Notneighborcheck = 1;
				break;
			}
		}

		if(Notneighborcheck == 0)
			Notneighbor[nNotneighbor++] = n2;
	}

	for(i=0; i<deg[n1]; i++)
		neighborcsize[i] = dirBFS(n1, A[n1][i], A, deg);
	for(i=0; i<nNotneighbor; i++)
		Notneighborcsize[i] = dirBFS(n1, Notneighbor[i], A, deg);

	Notorderedcheck = 0;
	for(i=0; i<deg[n1]; i++)
	{
		for(j=0; j<nNotneighbor; j++)
		{
			if(Notneighborcsize[j] < neighborcsize[i])
				Notorderedcheck = 1;
		}
	}

	return Notorderedcheck;
}

long checkNotorderedInf(long n1)
{
	long i, j, n2, Notorderedcheck;
	long Notneighborcheck, Notneighbor[degree], nNotneighbor;
	long neighborcluster[degree], Notneighborcluster[degree];
	long mclustercheck, Notmclustercheck;

	nNotneighbor = 0;
	for(i=0; i<linkdeg[n1]; i++)
	{
		n2 = link[n1][i];
		Notneighborcheck=0;
		for(j=0; j<deg[n1]; j++)
		{
			if(A[n1][j] == n2)
			{
				Notneighborcheck = 1;
				break;
			}
		}

		if(Notneighborcheck == 0)
			Notneighbor[nNotneighbor++] = n2;
	}

	for(i=0; i<deg[n1]; i++)
		neighborcluster[i] = cluster[A[n1][i]];

	for(i=0; i<nNotneighbor; i++)
		Notneighborcluster[i] = cluster[Notneighbor[i]];

	Notmclustercheck = 0;
	for(i=0; i<nNotneighbor; i++)
	{
		if(mcluster != Notneighborcluster[i])
			Notmclustercheck = 1;
	}

	if(Notmclustercheck == 1)
	{
		mclustercheck = 0;
		for(i=0; i<deg[n1]; i++)
		{
			if(mcluster == neighborcluster[i])
				mclustercheck = 1;
		}

		if(mclustercheck == 1)
			return 1;
	}

	return 0;
}

void makenetwork(long **link)
{
	long *largestubs, *smallstubs, Nlargestubs, Nsmallstubs;
	long L, i, j, k, t, n1index, n2index, n1stub, n2stub, check, ntrial, noexcesscheck;

	Nlargestubs = N*degree/2;
	Nsmallstubs = N*degree/2;
	L = N*degree/2;

	largestubs = (long*)malloc(sizeof(long)*Nlargestubs);
	smallstubs = (long*)malloc(sizeof(long)*Nsmallstubs);

	for(i=0; i<N; i++)
		linkdeg[i] = 0;

	for(i=0; i<N/2; i++)
	{
		for(j=0; j<degree; j++)
		{
			smallstubs[i*degree+j] = i;
			largestubs[i*degree+j] = i+N/2;
		}
	}

	for(t = 1; t <= L; ++t)
	{
		ntrial = 0, noexcesscheck = 0;
		while(1)
		{
			if(ntrial > (Nsmallstubs+Nlargestubs)*N)
			{
				noexcesscheck = 1;
				break;
			}

			ntrial ++;

			n1stub = drand48()*Nsmallstubs;
			n2stub = drand48()*Nlargestubs;
			n1index = smallstubs[n1stub];
			n2index = largestubs[n2stub];

			if(n1index == n2index)
				continue;

			check = 0;
			for(i=0; i<linkdeg[n1index]; i++)
			{
				if(link[n1index][i] == n2index)
				{
					check = 1;
					break;
				}
			}

			if(check == 0)
				break;
		}

		if(noexcesscheck == 1)
			break;

		smallstubs[n1stub] = smallstubs[Nsmallstubs-1], largestubs[n2stub] = largestubs[Nlargestubs-1];

		Nsmallstubs --, Nlargestubs --;

		link[n1index][linkdeg[n1index]] = n2index, link[n2index][linkdeg[n2index]] = n1index;
		linkdeg[n1index]++, linkdeg[n2index]++;
	}

	free(largestubs), free(smallstubs);
}

long getNewRewirelist(long* NewRewiringlist, long nNewRewiringlist)
{
	long i, j, k, n1, n2;
	long Rewiringlist[nNewRewiringlist];
	long nRewiringlist = nNewRewiringlist;
	for(i=0; i<nRewiringlist; i++)
		Rewiringlist[i] = NewRewiringlist[i];

	nNewRewiringlist = 0; 

	for(i=0; i<nRewiringlist; i++)
	{
		n1 = Rewiringlist[i];
		for(j=0; j<deg[n1]; j++)
		{
			n2 = A[n1][j];
			for(k=0; k<deg[n2]; k++)
			{
				if(A[n2][k] != n1 && Rewiringcheck[A[n2][k]] == 0)
				{
					Rewiringcheck[A[n2][k]] = 1;
					NewRewiringlist[nNewRewiringlist++] = A[n2][k];
				}
			}
		}
	}

	return nNewRewiringlist;
}
